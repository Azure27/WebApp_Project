<?php 

		$servername = "localhost";
		$username= "1335972";
		$password="Jamespauline27";	

		$con=mysqli_connect($servername,$username,$password);

		mysqli_select_db($con,"1335972");

	if(isset($_GET['i'])){
		$i = $_GET['i'];


		$result = mysqli_query($con, "SELECT * FROM projecttable WHERE user_id=$i");

		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

		echo "<form method='post'>";

		echo "<input type='text' name='username' value='".$row['username']."'>";
		echo "<input type='text' name='email' value='".$row['email']."'>";
		echo "<input type='text' name='lname' value='".$row['lname']."'>";
		echo "<input type='text' name='fname' value='".$row['fname']."'>";
		echo "<input type='text' name='mname' value='".$row['mname']."'>";
		echo "<input type='hidden' name='i' value='".$i."'>";

		echo "<input type = 'submit' name='update' value='UPDATE'>";
		
		echo "<a href='session.php'>BACK</a>";

		echo "</form>";

	}

	if(isset($_POST['update'])){

		$uname = $_POST['username'];
		$email = $_POST['email'];
		$lname = $_POST['lname'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$i = $_POST['i'];


		$sql = "UPDATE projecttable SET username='$uname',email='$email',fname='$fname',lname='$lname',mname='$mname' WHERE user_id=$i";
		$result = mysqli_query($con,$sql);

		$sql2 = "SELECT * FROM projecttable WHERE username='$uname' OR email='$email'";
		$result2=mysqli_query($con,$sql2);
		$result3 = mysqli_num_rows($result2);

		if($result){
			
			if($result3==0){
			echo "Updated!";
			header('location:session.php');
			}
			else{

				echo "Username or Email Exists!";

			}
		}else{
			echo "Error!";
		}

	}
	


 ?>

