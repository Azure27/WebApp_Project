<?php 
	session_start();
if(isset($_SESSION['start'])){

	$UID = $_SESSION['start'];
	$servername = "localhost";
		$username= "1335972";
		$password="Jamespauline27";

		$con=mysqli_connect($servername,$username,$password);

		// Check connection
		if (mysqli_connect_error())
		  {
		  echo "Failed to connect to MySQL: " . mysqli_connect_error();
		  }
		else{


			mysqli_select_db($con,"felicia_tamayo_projectdb");

			$sql = "SELECT * FROM projecttable WHERE user_id='$UID'";
			$result=mysqli_query($con,$sql);

			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

			echo "<div>";

			echo "Username:"."$row[username]</br>";
			echo "Last Name:"."$row[lname]</br>";
			echo "First Name:"."$row[fname]</br>";
			echo "Middle Name:"."$row[mname]</br>";
			echo "Gender:"."$row[gender]</br>";
			echo "E-Mail:"."$row[email]</br>";

			echo "</div>";
			
			echo "<a href = 'edit.php?i=".$row['user_id']."'>EDIT</a>";
		
		}

		

}else{
	echo "Please Login First!";
}
if(isset($_POST['logout'])){


			session_destroy();
			header('location:login.php');

		}
	
 ?>
<form method="post">
	<input type="submit" value="Logout" name="logout">
</form>

